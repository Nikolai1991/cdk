"use strict";
exports.__esModule = true;
exports.handler = void 0;
var aws_cloudformation_custom_resource_1 = require("aws-cloudformation-custom-resource");
var AWS = require("aws-sdk");
var ec2 = new AWS.EC2();
var secretsmanager = new AWS.SecretsManager();
var logger = new aws_cloudformation_custom_resource_1.StandardLogger();
exports.handler = function (event, context, callback) {
    new aws_cloudformation_custom_resource_1.CustomResource(context, callback, logger)
        .onCreate(Create)
        .onUpdate(Update)
        .onDelete(Delete)
        .handle(event);
};
function Create(event) {
    logger.info("Attempting to create EC2 Key Pair " + event.ResourceProperties.Name);
    return new Promise(function (resolve, reject) {
        createKeyPair(event)
            .then(savePrivaterKey)
            .then(function (data) {
            resolve(data);
        })["catch"](function (err) {
            reject(err);
        });
    });
}
function Update(event) {
    logger.info("Attempting to update EC2 Key Pair " + event.OldResourceProperties.Name);
    return new Promise(function (resolve, reject) {
        if (event.ResourceProperties.Name !== event.OldResourceProperties.Name) {
            reject(new Error('A Key Pair cannot be renamed. Please create a new Key Pair instead'));
        }
        updateKeyPair(event)
            .then(updatePrivaterKey)
            .then(updatePrivaterKeyAddTags)
            .then(updatePrivaterKeyRemoveTags)
            .then(function (data) {
            resolve(data);
        })["catch"](function (err) {
            reject(err);
        });
    });
}
function Delete(event) {
    logger.info("Attempting to delete EC2 Key Pair " + event.ResourceProperties.Name);
    return new Promise(function (resolve, reject) {
        deleteKeyPair(event)
            .then(deletePrivaterKey)
            .then(function (data) {
            resolve(data);
        })["catch"](function (err) {
            reject(err);
        });
    });
}
function createKeyPair(event) {
    return new Promise(function (resolve, reject) {
        ec2.createKeyPair({
            KeyName: event.ResourceProperties.Name
        }, function (err, data) {
            if (err)
                return reject(err);
            event.addResponseValue('KeyPairName', data.KeyName);
            event.KeyFingerprint = data.KeyFingerprint;
            event.KeyMaterial = data.KeyMaterial;
            resolve(event);
        });
    });
}
function updateKeyPair(event) {
    return new Promise(function (resolve, reject) {
        // there is nothing to update. a key cannot be changed
        event.addResponseValue('KeyPairName', event.ResourceProperties.Name);
        resolve(event);
    });
}
function deleteKeyPair(event) {
    return new Promise(function (resolve, reject) {
        ec2.deleteKeyPair({
            KeyName: event.ResourceProperties.Name
        }, function (err, data) {
            if (err)
                return reject(err);
            event.addResponseValue('KeyPairName', event.ResourceProperties.Name);
            resolve(event);
        });
    });
}
function savePrivaterKey(event) {
    return new Promise(function (resolve, reject) {
        secretsmanager.createSecret({
            Name: "" + event.ResourceProperties.SecretPrefix + event.ResourceProperties.Name,
            Description: event.ResourceProperties.Description,
            SecretString: event.KeyMaterial,
            KmsKeyId: event.ResourceProperties.Kms,
            Tags: makeTags(event, event.ResourceProperties)
        }, function (err, data) {
            if (err)
                return reject(err);
            event.addResponseValue('PrivateKeyARN', data.ARN);
            resolve(event);
        });
    });
}
function updatePrivaterKey(event) {
    return new Promise(function (resolve, reject) {
        secretsmanager.updateSecret({
            SecretId: "" + event.ResourceProperties.SecretPrefix + event.ResourceProperties.Name,
            Description: event.ResourceProperties.Description,
            KmsKeyId: event.ResourceProperties.Kms
        }, function (err, data) {
            if (err)
                return reject(err);
            event.addResponseValue('PrivateKeyARN', data.ARN);
            resolve(event);
        });
    });
}
function updatePrivaterKeyAddTags(event) {
    logger.info("Attempting to update tags for EC2 private key " + event.ResourceProperties.Name);
    return new Promise(function (resolve, reject) {
        var oldTags = makeTags(event, event.OldResourceProperties);
        var newTags = makeTags(event, event.ResourceProperties);
        if (JSON.stringify(oldTags) == JSON.stringify(newTags)) {
            logger.info("No changes of tags detected for EC2 private key " + event.ResourceProperties.Name + ". Not attempting any update");
            return resolve(event);
        }
        secretsmanager.tagResource({
            SecretId: "" + event.ResourceProperties.SecretPrefix + event.ResourceProperties.Name,
            Tags: newTags
        }, function (err, data) {
            if (err)
                return reject(err);
            resolve(event);
        });
    });
}
function updatePrivaterKeyRemoveTags(event) {
    logger.info("Attempting to remove some tags for EC2 private key " + event.ResourceProperties.Name);
    return new Promise(function (resolve, reject) {
        var oldTags = makeTags(event, event.OldResourceProperties);
        var newTags = makeTags(event, event.ResourceProperties);
        var tagsToRemove = getMissingTags(oldTags, newTags);
        if (JSON.stringify(oldTags) == JSON.stringify(newTags) ||
            !tagsToRemove.length) {
            logger.info("No changes of tags detected for EC2 private key " + event.ResourceProperties.Name + ". Not attempting any update");
            return resolve(event);
        }
        logger.info("Will remove the following tags: " + JSON.stringify(tagsToRemove));
        secretsmanager.untagResource({
            SecretId: "" + event.ResourceProperties.SecretPrefix + event.ResourceProperties.Name,
            TagKeys: tagsToRemove
        }, function (err, data) {
            if (err)
                reject(err);
            else
                resolve(event);
        });
    });
}
function deletePrivaterKey(event) {
    return new Promise(function (resolve, reject) {
        var options = {
            SecretId: "" + event.ResourceProperties.SecretPrefix + event.ResourceProperties.Name
        };
        var removePrivateKeyAfterDays = event.ResourceProperties
            .RemovePrivateKeyAfterDays;
        if (removePrivateKeyAfterDays > 0) {
            options.RecoveryWindowInDays =
                event.ResourceProperties.RemovePrivateKeyAfterDays;
        }
        else {
            options.ForceDeleteWithoutRecovery = true;
        }
        secretsmanager.deleteSecret(options, function (err, data) {
            if (err)
                return reject(err);
            event.addResponseValue('PrivateKeyARN', data.ARN);
            resolve(event);
        });
    });
}
function makeTags(event, properties) {
    var tags = [
        {
            Key: 'aws-cloudformation:stack-id',
            Value: event.StackId
        },
        {
            Key: 'aws-cloudformation:stack-name',
            Value: properties.StackName
        },
        {
            Key: 'aws-cloudformation:logical-id',
            Value: event.LogicalResourceId
        },
    ];
    if ('Tags' in properties) {
        Object.keys(properties.Tags).forEach(function (key) {
            tags.push({
                Key: key,
                Value: properties.Tags[key]
            });
        });
    }
    return tags;
}
function getMissingTags(oldTags, newTags) {
    var missing = oldTags.filter(missingTags(newTags));
    return missing.map(function (tag) {
        return tag.Key;
    });
}
function missingTags(newTags) {
    return function (currentTag) {
        return (newTags.filter(function (newTag) {
            return newTag.Key == currentTag.Key;
        }).length == 0);
    };
}
